#18个人（9名女性和9名男性）的体重,想知道女性体重是否与男性体重不同？
women_weight <- c(88.9, 81.2, 73.3, 21.8, 63.4, 84.6, 28.4, 28.8, 28.5)
men_weight <- c(37.8, 80, 33.4, 36, 89.4, 83.3, 97.3, 81.3, 92.4)
# 建立一个数据框
my_data <- data.frame( 
  group = rep(c("Woman", "Man"), each = 9),
  weight = c(women_weight,  men_weight)
)
#按性别计算统计信息（中位数和四分位数范围）可以使用dplyr软件包。
install.packages("dplyr")
library(dplyr)
group_by(my_data, group) %>%
  summarise(
    count = n(),
    mean = mean(weight, na.rm = TRUE),
    sd = sd(weight, na.rm = TRUE)
  )
#使用箱形图可视化数据
boxplot(weight ~ group, data=my_data, 
        main="Boxplot of my_data", xlab="group", ylab="weight",
        col = c("lightblue", "red"),
        border = "black")

#1、检验两独立样本是否满足正态分布
# Shapiro-Wilk normality test for Men's weights
with(my_data, shapiro.test(weight[group == "Man"]))  
# Shapiro-Wilk normality test for Women's weights
with(my_data, shapiro.test(weight[group == "Woman"])) 
两个p值小于显着性水平0.05，说明两组数据的分布与正态分布有显着差异。数据分布不符合正态分布的假设检验成立。

##（#with() 函数是 dplyr 包中的一个函数，它用于在给定的数据框（或tibble）上执行某些操作，而不需要重复数据框的名称。
## with(data（data：一个数据框或tibble），expr（要对数据执行的表达式）)

#2、检验个总体是否符合方差齐性，用F检验来检验方差齐性。用var.test()函数
res.ftest <- var.test(weight ~ group, data = my_data)
res.ftest
F检验为p 大于显着性水平0.05。因此，两组数据的方差之间没有显著差异。因此我们认为男女两组方差相等（方差齐性）。

#由于数据不符合正态分布，因此，我们不可以使用student-t检验。需要使用两独立样本Wilcoxon检验。

#计算两独立样本Wilcoxon检验
wilcox.test(weight ~ group, data = my_data,alternative = "two.sided", var.equal = TRUE)
p大于显著性水平，接受原假设，没有显著不同

