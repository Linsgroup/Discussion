# Kruskal-wallis秩和检验

x1 <- c(3.7,3.7,3.0,3.9,2.7)
x2 <- c(7.3,5.2,5.3,5.7,6.5)
x3 <- c(9.0,4.9,7.1,8.7)

n1 <- length(x1)
n2 <- length(x2)
n3 <- length(x3)
N <- n1 + n2 + n3
df <- 2

rank <- data.frame(cbind("x" = c(rep(1, n1), rep(2, n2), rep(3, n3)), "r" = rank(c(x1,x2,x3))))

R1 <- sum(rank$r[rank$x==1]); R1.bar <- R1/n1
R2 <- sum(rank$r[rank$x==2]); R2.bar <- R2/n2
R3 <- sum(rank$r[rank$x==3]); R3.bar <- R3/n3

rbind("Ri" = c(R1, R2, R3), "Ri.bar" = c(R1.bar, R2.bar, R3.bar))

H <- (12 / (N*(N+1))) * sum(c(R1, R2, R3)^2 / c(n1, n2, n3)) - 3*(N+1)

1 - pchisq(H, df) #卡方近似


kruskal.test(list(x1, x2, x3))
