# Friedman秩和检验

blead <- read.table("D:/桌面/R/blead.txt")

# 不打结数据的统计量的计算
X <- t(blead)
Y <- apply(X, 2, rank)
R <- apply(Y, 1, sum)
k <- nrow(X)
b <- ncol(X)

Q <- (12 / (b*k*(k+1))) * sum(R^2) - 3*b*(k+1)

W <- Q / (b*(k-1))

# p值的计算（近似计算）
1 - pchisq(Q, k-1)  #是卡方近似

#内置函数
friedman.test(as.matrix(blead)) #也是卡方近似








# 对于有结数据的优化

A <- c(55, 77, 90, 80)
B <- c(62, 65, 81, 75)
C <- c(60, 71, 80, 79)
D <- c(59, 72, 76, 75)
plot(A, B)

sing <- as.matrix(rbind(A, B, C, D))

QC <- function(x) {
  Y <- apply(x, 2, rank)
  R <- apply(Y, 1, sum)
  
  b <- ncol(x)
  k <- nrow(x)
  
  tau <- c()
  
  for (i in 1: ncol(x)) {
    u <- unique(x[, i])
    for (j in 1: length(u)) {
      if (sum(x[, i] == u[j]) > 1) {
        tau <- c(tau, sum(x[, i] == u[j]))
      }
    }
  }
  
  C <- sum(tau^3 - tau) / (b * k * (k^2 - 1))
  
  Q <- (12 / (b*k*(k+1))) * sum(R^2) - 3*b*(k+1)
  
  if (C != 0) {
    Qc <- Q / (1 - C)
  } else {
    Qc <- "There are no knots in the data."
  }
  
  list("C" = C, "tau" = tau, "Q" = Q, "Qc" = Qc, "df" = k-1)
}

result <- QC(sing)

result$C
result$tau
result$Q
result$Qc

QC(X)

1 - pchisq(result$Qc, result$df) #卡方近似
friedman.test(t(sing))  #也是卡方近似

